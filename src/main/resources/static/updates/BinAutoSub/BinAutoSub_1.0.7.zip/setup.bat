@echo off
setlocal EnableDelayedExpansion
chcp 65001 >nul 2>&1
cd /d "%~dp0"

echo ==========================================================
echo   BinAutoSub - Cai dat moi truong
echo ==========================================================
echo.

set "VENV=%~dp0backend\venv"
set "VPY=%VENV%\Scripts\python.exe"

REM ---------- 1. Tim Python phu hop ----------
echo [1/6] Tim Python...
set "BASEPY="

for %%V in (3.12 3.11 3.10) do (
    if not defined BASEPY (
        py -%%V --version >nul 2>&1
        if !errorlevel! equ 0 (
            set "BASEPY=py -%%V"
            echo       Dung Python %%V qua py launcher.
        )
    )
)

if not defined BASEPY (
    python --version >nul 2>&1
    if !errorlevel! equ 0 (
        for /f "tokens=2" %%a in ('python --version 2^>^&1') do set "PYVER=%%a"
        REM Kiem tra version >= 3.10 va <= 3.12
        for /f "tokens=1,2 delims=." %%x in ("!PYVER!") do (
            if %%x==3 if %%y GEQ 10 if %%y LEQ 12 (
                echo       Tim thay python !PYVER! trong PATH.
                set "BASEPY=python"
            ) else (
                echo       Python !PYVER! khong tuong thich. Can 3.10-3.12.
            )
        )
    )
)

if not defined BASEPY (
    echo.
    echo   [LOI] Khong tim thay Python.
    echo   Tai Python 3.12 tai https://www.python.org/downloads/
    echo   Khi cai nho TICK vao o "Add Python to PATH".
    echo.
    pause
    exit /b 1
)

REM ---------- 2. Tao venv ----------
echo.
echo [2/6] Tao moi truong rieng tai backend\venv ...

if exist "%VPY%" (
    echo       Da co san, dung lai.
) else (
    if not exist "%~dp0backend" mkdir "%~dp0backend"
    %BASEPY% -m venv "%VENV%"
    if !errorlevel! neq 0 (
        echo.
        echo   [LOI] Khong tao duoc venv.
        echo   Thu chay: %BASEPY% -m pip install --upgrade virtualenv
        pause
        exit /b 1
    )
    echo       Xong.
)

if not exist "%VPY%" (
    echo   [LOI] Khong thay %VPY%
    pause
    exit /b 1
)

"%VPY%" -m pip install --upgrade pip --quiet

REM ---------- 3. PyTorch CUDA ----------
echo.
echo [3/6] Cai PyTorch...
echo       (lan dau tai khoang 2-3 GB, kien nhan cho)

where nvidia-smi >nul 2>&1
if !errorlevel! equ 0 (
    echo       Phat hien GPU NVIDIA - cai ban CUDA 12.8.
    "%VPY%" -m pip install "torch==2.8.0" "torchaudio==2.8.0" "torchvision==0.23.0" --index-url https://download.pytorch.org/whl/cu128
) else (
    echo       Khong thay GPU NVIDIA - cai ban CPU. Xu ly se cham hon nhieu.
    "%VPY%" -m pip install "torch==2.8.0" "torchaudio==2.8.0" "torchvision==0.23.0"
)

if !errorlevel! neq 0 (
    echo.
    echo   [LOI] Cai PyTorch that bai. Kiem tra ket noi mang roi chay lai setup.bat.
    pause
    exit /b 1
)

REM ---------- 4. Cac goi con lai ----------
echo.
echo [4/6] Cai cac goi xu ly...

pushd "%~dp0backend"
if exist "_deps.pyd" (
    "%VPY%" -c "from _deps import install; install()"
) else if exist "_deps.py" (
    "%VPY%" -c "from _deps import install; install()"
) else if exist "main.py" (
    "%VPY%" main.py --setup
) else (
    echo   [CANH BAO] Khong tim thay file cai dat goi phu thuoc.
)
popd

if !errorlevel! neq 0 (
    echo.
    echo   [LOI] Cai goi that bai. Xem thong bao loi o tren.
    pause
    exit /b 1
)

REM ---------- 5. FFmpeg ----------
echo.
echo [5/6] Kiem tra FFmpeg...

set "FFOK=1"
if not exist "%~dp0tools\ffmpeg.exe" set "FFOK="
if not exist "%~dp0tools\ffprobe.exe" set "FFOK="

if defined FFOK (
    echo       Da co san.
) else (
    echo       Tai FFmpeg khoang 80 MB...
    if not exist "%~dp0tools" mkdir "%~dp0tools"
    powershell -NoProfile -ExecutionPolicy Bypass -Command "$ErrorActionPreference='Stop'; $u='https://github.com/BtbN/FFmpeg-Builds/releases/download/autobuild-2026-04-30-13-44/ffmpeg-n7.1.3-46-g957b06a788-win64-gpl-7.1.zip'; $z=Join-Path $env:TEMP 'bas_ffmpeg.zip'; $d=Join-Path $env:TEMP 'bas_ffmpeg'; Invoke-WebRequest -Uri $u -OutFile $z -UseBasicParsing; if(Test-Path $d){Remove-Item $d -Recurse -Force}; Expand-Archive -Path $z -DestinationPath $d -Force; Get-ChildItem $d -Recurse -Include ffmpeg.exe,ffprobe.exe | ForEach-Object { Copy-Item $_.FullName -Destination '%~dp0tools' -Force }; Remove-Item $z -Force; Remove-Item $d -Recurse -Force"
    if !errorlevel! neq 0 (
        echo       [CANH BAO] Tai FFmpeg that bai.
        echo       Khong sao - tool se tu tai lai khi mo lan dau.
    ) else (
        echo       Xong.
    )
)

REM ---------- 6. Kiem tra ----------
echo.
echo [6/6] Kiem tra moi truong...
echo.

"%VPY%" -c "import sys; print('  Python      :', sys.version.split()[0])"

"%VPY%" -c "import torch; print('  GPU         :', torch.cuda.get_device_name(0) if torch.cuda.is_available() else 'KHONG (chay CPU)')"

"%VPY%" -c "print('  Backend     : OK')"

echo.
"%VPY%" -m pip check
if !errorlevel! neq 0 (
    echo   [CANH BAO] pip bao co goi xung dot - xem o tren.
    echo   Van co the chay duoc, nhung neu loi thi bao lai.
) else (
    echo   Khong co xung dot goi nao.
)

echo.
echo ==========================================================
echo   XONG. Mo BinAutoSub.exe de bat dau.
echo ==========================================================
echo.
echo   Moi truong nam o: backend\venv
echo   Xoa thu muc do roi chay lai setup.bat de cai lai tu dau.
echo.
pause
