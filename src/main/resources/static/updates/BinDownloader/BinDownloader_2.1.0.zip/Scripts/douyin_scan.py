"""
Douyin utility script for VideoDownloader WPF app.
This script is kept as a fallback/utility. The main Douyin integration 
now uses Evil0ctal/Douyin_TikTok_Download_API (FastAPI REST server).

This script can:
  - Check if the API server is running
  - Start the API server
  - Extract Douyin cookies from browser
"""
import sys
import os
import json
import subprocess
import argparse


def main():
    parser = argparse.ArgumentParser(description="Douyin utility")
    parser.add_argument("--check-server", action="store_true",
                        help="Check if API server is running")
    parser.add_argument("--start-server", type=str, default="",
                        help="Path to Douyin_TikTok_Download_API repo")
    parser.add_argument("--extract-cookies", type=str, default="chrome",
                        help="Extract Douyin cookies from browser")
    parser.add_argument("--port", type=int, default=8764,
                        help="API server port")
    args = parser.parse_args()

    if args.check_server:
        check_server(args.port)
    elif args.start_server:
        start_server(args.start_server, args.port)
    elif args.extract_cookies:
        cookies = extract_douyin_cookies(args.extract_cookies)
        print(json.dumps(cookies, ensure_ascii=False))


def check_server(port):
    """Check if the Douyin API server is running."""
    import urllib.request
    try:
        url = f"http://127.0.0.1:{port}/docs"
        req = urllib.request.Request(url, method="GET")
        resp = urllib.request.urlopen(req, timeout=5)
        print(json.dumps({"running": True, "status": resp.status}))
    except Exception as e:
        print(json.dumps({"running": False, "error": str(e)}))


def start_server(repo_dir, port):
    """Start the Douyin API server."""
    start_py = os.path.join(repo_dir, "start.py")
    if not os.path.exists(start_py):
        print(json.dumps({"error": f"start.py not found at {start_py}"}))
        sys.exit(1)

    env = os.environ.copy()
    env["PYTHONUTF8"] = "1"
    env["PYTHONIOENCODING"] = "utf-8"

    proc = subprocess.Popen(
        [sys.executable, start_py],
        cwd=repo_dir,
        env=env,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
    )
    print(json.dumps({"started": True, "pid": proc.pid}))


def extract_douyin_cookies(browser_name):
    """Extract Douyin cookies from browser."""
    cookie_keys = [
        "msToken", "ttwid", "odin_tt", "passport_csrf_token",
        "sid_guard", "sessionid", "sessionid_ss", "sid_tt"
    ]
    result = {k: "" for k in cookie_keys}

    try:
        import browser_cookie3
        browser_map = {
            "chrome": browser_cookie3.chrome,
            "firefox": browser_cookie3.firefox,
            "edge": browser_cookie3.edge,
            "opera": browser_cookie3.opera,
            "brave": browser_cookie3.brave,
        }
        getter = browser_map.get(browser_name.lower())
        if getter:
            cj = getter(domain_name=".douyin.com")
            for cookie in cj:
                if cookie.name in cookie_keys:
                    result[cookie.name] = cookie.value
    except ImportError:
        print("[warn] browser_cookie3 not installed", file=sys.stderr)
    except Exception as e:
        print(f"[warn] cookie extraction: {e}", file=sys.stderr)

    return result


if __name__ == "__main__":
    main()
