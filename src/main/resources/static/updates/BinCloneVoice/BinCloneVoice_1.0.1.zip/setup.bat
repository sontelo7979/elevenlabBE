@echo off
title Voice Clone Pro - Setup
color 0A

echo ==================================================
echo   Voice Clone Pro - Cai dat tu dong
echo ==================================================
echo.

:: --- Kiem tra quyen Admin ---
net session >nul 2>&1
if errorlevel 1 (
    echo [!] Can chay voi quyen Administrator
    echo     Click chuot phai - Run as administrator
    pause
    exit /b 1
)

:: --- Xac dinh thu muc ---
:: Tim thu muc chua setup.bat (co the la PythonBackend hoac BinCloneVoice)
set "BACKEND=%~dp0"
:: Bo dau \ cuoi
if "%BACKEND:~-1%"=="\" set "BACKEND=%BACKEND:~0,-1%"

echo [INFO] Thu muc backend: %BACKEND%
echo.

:: ==================================================
::  BUOC 1: KIEM TRA NVIDIA GPU
:: ==================================================
echo -- Buoc 1/4: Kiem tra GPU --
nvidia-smi >nul 2>&1
if errorlevel 1 (
    echo [CANH BAO] Khong tim thay NVIDIA GPU hoac driver.
    echo            Tool van chay duoc nhung se cham hon.
    echo            Neu co GPU NVIDIA, cai driver tai: https://www.nvidia.com/drivers
    echo.
    set "HAS_GPU=0"
) else (
    echo [OK] Tim thay NVIDIA GPU:
    nvidia-smi --query-gpu=name,memory.total --format=csv,noheader 2>nul
    echo.
    set "HAS_GPU=1"
)

:: ==================================================
::  BUOC 2: KIEM TRA / CAI PYTHON 3.11
:: ==================================================
echo -- Buoc 2/4: Kiem tra Python --

:: Kiem tra venv da co chua
if exist "%BACKEND%\venv\Scripts\python.exe" (
    echo [OK] Moi truong da duoc cai dat.
    goto :check_packages
)

:: Tim Python 3.11 trong he thong
set "PY311="

for /d %%D in ("%LOCALAPPDATA%\Programs\Python\Python311*") do (
    if exist "%%D\python.exe" set "PY311=%%D\python.exe"
)

if not defined PY311 (
    where python >nul 2>&1
    if not errorlevel 1 (
        for /f "tokens=*" %%V in ('python -c "import sys; print(str(sys.version_info.major)+'.'+str(sys.version_info.minor))" 2^>nul') do (
            if "%%V"=="3.11" (
                for /f "tokens=*" %%P in ('where python') do set "PY311=%%P"
            )
        )
    )
)

if not defined PY311 (
    where py >nul 2>&1
    if not errorlevel 1 (
        py -3.11 --version >nul 2>&1
        if not errorlevel 1 set "PY311=py -3.11"
    )
)

if defined PY311 (
    echo [OK] Tim thay Python 3.11: %PY311%
    goto :create_venv
)

echo [!] Khong tim thay Python 3.11
echo.
echo     Dang tai Python 3.11.9 ...
echo.

powershell -Command "& { [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12; Invoke-WebRequest -Uri 'https://www.python.org/ftp/python/3.11.9/python-3.11.9-amd64.exe' -OutFile '%TEMP%\python-3.11.9-amd64.exe' }"

if not exist "%TEMP%\python-3.11.9-amd64.exe" (
    echo [LOI] Khong tai duoc. Kiem tra ket noi mang.
    echo       Hoac tai thu cong tai: https://www.python.org/downloads/release/python-3119/
    pause
    exit /b 1
)

echo     Dang cai dat Python 3.11.9...
"%TEMP%\python-3.11.9-amd64.exe" /quiet InstallAllUsers=0 PrependPath=1 Include_test=0 Include_launcher=1

timeout /t 10 /nobreak >nul

set "PY311="
for /d %%D in ("%LOCALAPPDATA%\Programs\Python\Python311*") do (
    if exist "%%D\python.exe" set "PY311=%%D\python.exe"
)

if defined PY311 (
    echo [OK] Da cai Python 3.11 thanh cong!
) else (
    echo [LOI] Cai Python that bai.
    echo       Tai thu cong tai: https://www.python.org/downloads/release/python-3119/
    echo       Chon "Windows installer (64-bit)", tick "Add to PATH" khi cai.
    pause
    exit /b 1
)

:: ==================================================
::  BUOC 3: TAO VENV VA CAI PACKAGES
:: ==================================================
:create_venv
echo.
echo -- Buoc 3/4: Cai dat moi truong xu ly --

if not exist "%BACKEND%\venv" (
    echo     Dang tao moi truong...
    "%PY311%" -m venv "%BACKEND%\venv"
    if errorlevel 1 (
        echo [LOI] Khong tao duoc moi truong.
        pause
        exit /b 1
    )
    echo [OK] Da tao moi truong.
)

:check_packages
"%BACKEND%\venv\Scripts\python.exe" -c "import omnivoice; import fastapi" >nul 2>&1
if not errorlevel 1 (
    echo [OK] Tat ca thanh phan da cai san.
    goto :done
)

echo     Dang cai dat cac thanh phan xu ly (lan dau mat 5-15 phut, can internet)...
echo.

echo     [1/3] Cai dat engine xu ly AI (~2.7GB)...
"%BACKEND%\venv\Scripts\pip.exe" install torch==2.6.0+cu118 torchaudio==2.6.0+cu118 --index-url https://download.pytorch.org/whl/cu118 --no-cache-dir -q
if errorlevel 1 (
    echo [LOI] Cai dat engine AI that bai. Kiem tra ket noi mang.
    pause
    exit /b 1
)

echo     [2/3] Cai dat module clone voice...
"%BACKEND%\venv\Scripts\pip.exe" install omnivoice --no-cache-dir -q
if errorlevel 1 (
    echo [LOI] Cai dat module clone voice that bai.
    pause
    exit /b 1
)

echo     [3/3] Cai dat cac thanh phan phu tro...
"%BACKEND%\venv\Scripts\pip.exe" install "omnivoice[tn]" fastapi uvicorn python-multipart pydub --no-cache-dir -q
if errorlevel 1 (
    echo [LOI] Cai dat thanh phan phu tro that bai.
    pause
    exit /b 1
)

echo.
echo [OK] Da cai dat tat ca thanh phan!

:: ==================================================
::  BUOC 4: KIEM TRA TONG THE
:: ==================================================
:done
echo.
echo -- Buoc 4/4: Kiem tra tong the --

set "CHECK_OK=1"

if not exist "%BACKEND%\venv\Scripts\python.exe" (
    echo [LOI] Khong tim thay Python trong moi truong.
    set "CHECK_OK=0"
)

if not exist "%BACKEND%\server.py" (
    echo [LOI] Khong tim thay file server.
    set "CHECK_OK=0"
)

if not exist "%BACKEND%\ffmpeg.exe" (
    echo [CANH BAO] Khong tim thay ffmpeg. Xu ly audio dai co the bi loi.
)

if "%CHECK_OK%"=="0" (
    echo.
    echo [LOI] Cai dat chua hoan tat. Vui long chay lai setup.
    pause
    exit /b 1
)

echo [OK] Tat ca thanh phan da san sang!
echo.

echo ==================================================
echo   CAI DAT HOAN TAT!
echo ==================================================
echo.
if "%HAS_GPU%"=="1" (
    echo   Phan cung   : Da phat hien GPU -- toc do nhanh
) else (
    echo   Phan cung   : Khong co GPU -- chay tren CPU
)
echo   Trang thai  : San sang su dung
echo.
echo   Huong dan:
echo   1. Mo file VoiceCloneTool.exe
echo   2. Lan dau chay se tai du lieu AI (~2GB), can internet
echo   3. Sau lan dau khong can internet nua
echo.
pause
